# Media Viewer Playlist Example

This example shows how to configure a plugin to display custom content in MediaViewer with playlist navigation and filtering.

## Example: Video Player Plugin

```typescript
import { IMediaViewer, Actions } from "@onlyoffice/docspace-plugin-sdk";

// Configure media viewer with playlist
const mediaViewerConfig: IMediaViewer = {
  fileId: 12345,
  title: "Custom Video Player",
  
  // Enable playlist navigation
  enablePlaylist: true,
  
  // Filter configuration
  playlistFilter: {
    // Only show video files
    allowedExtensions: [".mp4", ".avi", ".mkv", ".webm"],
    
    // Require download permission
    requiredSecurity: {
      Read: true,
      Download: true,
    },
  },
  
  // Navigation callbacks
  navigation: {
    onNext: () => {
      console.log("User navigated to next video");
      return {
        actions: [Actions.showToast],
        toastProps: [{ title: "Next video" }],
      };
    },
    
    onPrevious: () => {
      console.log("User navigated to previous video");
      return {
        actions: [Actions.showToast],
        toastProps: [{ title: "Previous video" }],
      };
    },
    
    onFileChange: (fileId) => {
      console.log(`File changed to: ${fileId}`);
      // Update your player
    },
  },
  
  // Custom content
  content: {
    widthProp: "100%",
    heightProp: "100%",
    displayProp: "flex",
    children: [
      {
        component: "iframe",
        props: {
          src: "https://player.example.com/video/12345",
          width: "100%",
          height: "100%",
        },
      },
    ],
  },
  
  onClose: () => {
    return { actions: [Actions.closeMediaViewer] };
  },
};

// Show media viewer
plugin.showMediaViewer(mediaViewerConfig);
```

## How It Works

1. **Filtering**: When `enablePlaylist: true`, the system filters files in the current folder based on `playlistFilter` criteria (extensions, security permissions).

2. **Playlist**: Filtered files form a playlist that users can navigate through.

3. **Navigation**: Users navigate with prev/next buttons or keyboard. Your callbacks are invoked before navigation.

4. **Security**: All file permissions are checked automatically.

## Filter Options

### `allowedExtensions`
Array of file extensions to include:
```typescript
allowedExtensions: [".mp4", ".avi"]  // Only videos
allowedExtensions: [".jpg", ".png"]  // Only images
```

### `requiredSecurity`
Required file permissions:
```typescript
requiredSecurity: {
  Read: true,      // File must be readable
  Download: true,  // File must be downloadable
  Edit: true,      // File must be editable
}
```

## Navigation Callbacks

### `onNext()`
Called when navigating to next file:
```typescript
onNext: () => {
  saveCurrentState();
  return { actions: [Actions.showToast], toastProps: [{ title: "Next" }] };
}
```

### `onPrevious()`
Called when navigating to previous file:
```typescript
onPrevious: () => {
  saveCurrentState();
}
```

### `onFileChange(fileId)`
Called when file changes:
```typescript
onFileChange: (fileId) => {
  loadFileData(fileId);
}
```
